<?php
//
// Archivo con los datos de configuración de la base de datos
//


// array con los datos que se utilizarán para la conexión a la base de datos
$dbConfig = array(
	'driver'   =>	'mysql',
	'host'     =>	'localhost',
	'dbname'   =>	'ventas_comerciales',
	'usuario'  =>	'ut7', 
	'password' =>	'ut7'
	);
?>
