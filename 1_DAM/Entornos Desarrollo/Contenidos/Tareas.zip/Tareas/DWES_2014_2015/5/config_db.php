<?php

//
// Archivo con los datos de configuración de la base de datos
//


// array con los datos que se utilizarán para la conexión a la base de datos
$dbConfig = array(
	'driver'   =>	'mysql',
	'host'     =>	'localhost',
	'dbname'   =>	'tarea4',
	'usuario'  =>	'usu4', 
	'password' =>	'usu4'
	);

?>
