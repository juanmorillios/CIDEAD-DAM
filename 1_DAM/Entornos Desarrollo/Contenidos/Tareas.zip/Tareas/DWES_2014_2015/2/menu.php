<div id="contenedor_menu"> 
	<div class="menu">
	    <input type="submit" name="accion" value="Mostrar lista" />
	    <input type="submit" name="accion" value="Insertar" />
	    <input type="submit" name="accion" value="Modificar" />
	    <input type="submit" name="accion" value="Eliminar" />
	</div>
</div>