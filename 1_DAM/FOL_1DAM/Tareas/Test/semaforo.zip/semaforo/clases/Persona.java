package clases;
// Clase utilizada para ser herencia de estudiante y profesor
public class Persona {
	// Metodos de clase. Edad y nombre
	int i_Edad;	
	String s_Nombre;		
    }
